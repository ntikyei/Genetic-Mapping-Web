// main.js
// Navigation toggle, logo glow toggle, and contact form validation

document.addEventListener('DOMContentLoaded', function () {
  // NAV TOGGLES: use class-based open/close to avoid inline styles
  document.querySelectorAll('.nav-toggle').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var id = btn.id || '';
      var navId = id.replace('nav-toggle', 'main-nav');
      var nav = document.getElementById(navId);
      if (!nav) return;

      var expanded = btn.getAttribute('aria-expanded') === 'true';
      var nextExpanded = (!expanded).toString();
      btn.setAttribute('aria-expanded', nextExpanded);
      btn.setAttribute('aria-label', nextExpanded === 'true' ? 'Close menu' : 'Open menu');

      nav.classList.toggle('is-open', nextExpanded === 'true');
    });
  });

  // Close mobile nav when clicking outside
  document.addEventListener('click', function (e) {
    document.querySelectorAll('[id^="main-nav"]').forEach(function (nav) {
      var toggle = document.getElementById(nav.id.replace('main-nav', 'nav-toggle'));
      var isOpen = nav.classList.contains('is-open');
      var clickedToggle = e.target.classList.contains('nav-toggle') || !!e.target.closest('.nav-toggle');
      if (isOpen && !nav.contains(e.target) && !clickedToggle) {
        nav.classList.remove('is-open');
        if (toggle) {
          toggle.setAttribute('aria-expanded', 'false');
          toggle.setAttribute('aria-label', 'Open menu');
        }
      }
    });
  });

  // Contact form validation
  const form = document.getElementById('contact-form');
  if (form) {
    form.addEventListener('submit', function (e) {
      e.preventDefault();

      const name = form.querySelector('#name').value.trim();
      const email = form.querySelector('#email').value.trim();
      const message = form.querySelector('#message').value.trim();
      const status = document.getElementById('form-status');

      if (!name || !email || !message) {
        status.textContent = 'Please complete all required fields.';
        status.style.color = 'crimson';
        return;
      }

      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        status.textContent = 'Please enter a valid email address.';
        status.style.color = 'crimson';
        return;
      }

      status.textContent = 'Thanks — your message has been recorded (demo).';
      status.style.color = 'green';
      form.reset();
    });
  }
});
